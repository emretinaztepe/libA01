The slides in this folder can be used in a classroom setting and can also be used as a self-paced tutorials. Use the slides "withNotes" to see more details about each slide. 

NOTE: Microsoft Edge does not correctly render the class slides. To get the slides to render correctly, click on the "..." in top right of the Edge browser and then click once on zoom +. 

If using Internet Explorer or Edge, ensure that your browser is the most recent version (must be using document mode 10+)